﻿using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMS_BAL;

namespace CIMS_PL
{
    class Program
    {
        private void CarFunctions()
        {
            Console.WriteLine("-----------------------Car Information Management System-----------------------");
            Console.WriteLine("              ................Administartor................");
            int ch;
            do
            {
                DisplayMenu();
                Console.Write("\nChoose the task you want to perform:");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1: AddCar();
                        break;
                    case 2: UpdateCar();
                        break;
                    case 3: DeleteCar();
                        break;
                    case 4: SearchCarByName();
                        break;
                    case 5:
                        SearchCarByModel();
                        break;
                    case 6: GetListCar();
                        break;
                    default: Console.WriteLine("Please Enter suitable option");
                        break;
                }
                Console.Write("\nDo you want to perform other tasks(Yes or No):");
                Console.ReadLine();
            } while (ch>0&ch<7);
        }
        private void DisplayMenu()
        {
            Console.WriteLine("\n------------------------------------------------------------");
            Console.WriteLine("1.Add  Car");
            Console.WriteLine("2.UpdateCar");
            Console.WriteLine("3.Delete Car");
            Console.WriteLine("4.Search Car ByName");
            Console.WriteLine("5.Search Car ByModel");
            Console.WriteLine("6.GetList ");
            Console.WriteLine("-------------------------------------------------------------");
        }
        private void AddCar()
        {
            Car objCar = new Car();
            try
            {
                Console.WriteLine("\n******************Adding NewCar Details********************");
                Console.Write("\nEnter ManufacturerName  :");
                objCar.ManufacturerName = Console.ReadLine();
                Console.Write("Enter Model :");
                objCar.Model = Console.ReadLine();
                Console.Write("Enter Type(Hatchback,Sedan OR SUV) :");
                objCar.Type = Console.ReadLine();
                Console.Write("Enter Engine :");
                objCar.Engine = Console.ReadLine();
                Console.Write("Enter BHP---");
                objCar.BHP = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Transmission(Manual OR Automatic) :");
                objCar.Transmission = Console.ReadLine();
                Console.Write("Enter Mileage :");
                objCar.Mileage = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter No.of Seats :");
                objCar.Seats = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter AirBagDetails :");
                objCar.AirBagDetails = Console.ReadLine();
                Console.Write("Enter BootSpace :");
                objCar.BootSpace = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter CarColor :");
                objCar.Colour = Console.ReadLine();
                Console.Write("Enter Price :");
                objCar.Price = Convert.ToDouble(Console.ReadLine());

                bool CarAdded = CarBAL.AddCarBAL(objCar);
                if (CarAdded == true)
                {
                    Console.WriteLine("\nNew Car Details Added Successfully");
                }
                else
                {
                    Console.WriteLine("\nCar Details Could not be added");
                }
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }


        }
        private void UpdateCar()
        {
            Car objCar = new Car();
            try
            {
               
                Console.WriteLine("\n********************Updating Car Details********************");
                string UpdateModel;
                Console.WriteLine("\nEnter the model you want to modify");
                UpdateModel=Console.ReadLine();
                objCar=CarBAL.SearchCarByModelBAL(UpdateModel);
                if (objCar != null)
                {
                    Console.WriteLine("\nManufacturerName :" );
                    objCar.ManufacturerName = Console.ReadLine();
                    Console.WriteLine("Enter Model :");
                    objCar.Model = Console.ReadLine();
                    Console.WriteLine("Enter Type(Hatchback,Sedan OR SUV) :");
                    objCar.Type = Console.ReadLine();
                    Console.WriteLine("Enter Engine :");
                    objCar.Engine = Console.ReadLine();
                    Console.WriteLine("Enter BHP :");
                    objCar.BHP = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Transmission(Manual OR Automatic) :");
                    objCar.Transmission = Console.ReadLine();
                    Console.WriteLine("Enter Mileage :");
                    objCar.Mileage = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter No.of Seats :");
                    objCar.Seats = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter AirBagDetails :");
                    objCar.AirBagDetails = Console.ReadLine();
                    Console.WriteLine("Enter BootSpace :");
                    objCar.BootSpace = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter CarColor :");
                    objCar.Colour = Console.ReadLine();
                    Console.WriteLine("Enter Price :");
                    objCar.Price = Convert.ToDouble(Console.ReadLine());

                    bool CarUpdated = CarBAL.UpdateCarBAL(objCar);
                    if (CarUpdated == true)
                    {
                        Console.WriteLine("\nCar Details Updated Successfully");
                    }
                    else
                    {
                        Console.WriteLine("\nCar Details Could not be updated");
                    }
                }
                else
                {
                    Console.WriteLine("\nNo Car details Based on given model is available");
                }
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void DeleteCar()
        {
            Car objCar = new Car();
            try
            {

                Console.WriteLine("\n*********************Deleting Car Details*******************");
                string DeleteModel;
                Console.WriteLine("\nEnter the car model you want to delete");
                DeleteModel = Console.ReadLine();
                objCar = CarBAL.SearchCarByModelBAL(DeleteModel);
                if (objCar != null)
                {
                    Console.WriteLine("\nAre you sure that you want  to delete (Yes OR No)");
                    string s = Console.ReadLine();
                    if ((s == "yes") || (s == "Yes"))
                    {
                        bool CarDeleted = CarBAL.DeleteCarBAL(DeleteModel);
                        if (CarDeleted == true)
                            Console.WriteLine("\nCar Details deleted Successfully");
                        else
                            Console.WriteLine("\nCar Details Could not be deleted");
                    }
                }
                else
                {
                    Console.WriteLine("\nNo Car details Based on given model is available");
                }
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
            private void SearchCarByName()
        {
            Console.WriteLine("\n***************Searching for Car Details By Name*****************");

            try
            {
                string SearchName;
                Console.WriteLine("\nEnter the name of car you want to modify");
                SearchName = Console.ReadLine();
                Car objCar = CarBAL.SearchCarByNameBAL(SearchName);
                if (objCar != null)
                {
                    Console.WriteLine("\nManufacturerName : " + objCar.ManufacturerName);
                    Console.WriteLine("Model : " + objCar.Model);
                    Console.WriteLine("Type :" + objCar.Type);
                    Console.WriteLine("Engine : " + objCar.Engine);
                    Console.WriteLine("BHP :" + objCar.BHP);
                    Console.WriteLine("Transmission :" + objCar.Transmission);
                    Console.WriteLine("Mileage :" + objCar.Mileage);
                    Console.WriteLine("Seats :" + objCar.Seats);
                    Console.WriteLine("AirBagDetails :" + objCar.AirBagDetails);
                    Console.WriteLine("BootSpace :" + objCar.BootSpace);
                    Console.WriteLine("CarColour :" + objCar.Colour);
                    Console.WriteLine("Price :" + objCar.Price);
                }
                else
                    Console.WriteLine("\nCar could not be searched based on given model type");
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void SearchCarByModel()
        {
            Console.WriteLine("\n***************Saerching for Car Details By Model****************");

            try
            {
                string SearchModel;
                Console.WriteLine("\nEnter the model of car you want to modify");
                SearchModel = Console.ReadLine();
                Car objCar = CarBAL.SearchCarByModelBAL(SearchModel);
                if (objCar != null)
                {
                    Console.WriteLine("\nManufacturerName: " + objCar.ManufacturerName);
                    Console.WriteLine("Model: " + objCar.Model);
                    Console.WriteLine("Type:" + objCar.Type);
                    Console.WriteLine("Engine: " + objCar.Engine);
                    Console.WriteLine("BHP:" + objCar.BHP);
                    Console.WriteLine("Transmission:" + objCar.Transmission);
                    Console.WriteLine("Mileage:" + objCar.Mileage);
                    Console.WriteLine("Seats:" + objCar.Seats);
                    Console.WriteLine("AirBagDetails:" + objCar.AirBagDetails);
                    Console.WriteLine("BootSpace:" + objCar.BootSpace);
                    Console.WriteLine("CarColour :" + objCar.Colour);
                    Console.WriteLine("Price:" + objCar.Price);
                }
                else
                    Console.WriteLine("\nCar could not be searched based on given model type");
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void GetListCar()
        {
            //Car objCar = new Car();
            Console.WriteLine("\n\t \t************************List of Cars***********************");
            Console.WriteLine("\nEnter the Manufacturer :");
            string manufacturerName=Console.ReadLine();
            Console.WriteLine("Enter the Type:");
            string type = Console.ReadLine();
            List<Car> cars = CarBAL.GetListBAL();
            if (cars==null)
            {
                Console.WriteLine("Car List is Empty");
            }
            else
            {
                foreach (var car in cars)
                {
                    if (car.ManufacturerName == manufacturerName && car.Type == type)
                    {
                        Console.WriteLine("\nManufacturerName: " + car.ManufacturerName);
                        Console.WriteLine("Model: " + car.Model);
                        Console.WriteLine("Type:" + car.Type);
                        Console.WriteLine("CarColour :" + car.Colour);
                        Console.WriteLine("Price:" + car.Price);
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            Program objpg = new Program();
            objpg.CarFunctions();
            Console.ReadLine();
        }
    }
}
