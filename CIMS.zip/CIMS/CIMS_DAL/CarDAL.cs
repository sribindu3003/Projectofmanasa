﻿using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS_DAL
{
    public class CarDAL
    {
        public List<Car> objCars = new List<Car>();
        public bool AddCarDAL(Car objCar)
        {
            bool carAdded;
            try
            {
                objCars.Add(objCar);
                carAdded = true;
            }
            catch(CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carAdded ;
        }
        public bool UpdateCarDAL(Car objCar)
        {
            bool carUpdated = false;
            try
            {
                Car objcar = objCars.Find(c=>c.Model==objCar.Model);
                if(objcar!=null)
                {
                    objcar.ManufacturerName = objCar.ManufacturerName;
                    objcar.Model = objCar.Model;
                    objcar.Type = objCar.Type;
                    objcar.Engine = objCar.Engine;
                    objcar.BHP = objCar.BHP;
                    objcar.Transmission = objCar.Transmission;
                    objcar.Mileage = objCar.Mileage;
                    objcar.Seats = objCar.Seats;
                    objcar.AirBagDetails = objCar.AirBagDetails;
                    objcar.BootSpace = objCar.BootSpace;
                    objcar.Colour = objCar.Colour;
                    objcar.Price = objCar.Price;
                }
                carUpdated = true;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carUpdated;
        }
        public bool DeleteCarDAL(string model)
        {
            bool carDeleted = false;
            try
            {
                Car objcar = objCars.Find(c => c.Model == model);
                if (objcar != null)
                {
                    objCars.Remove(objcar);
                    carDeleted = true;
                }
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carDeleted;
        }
        public Car SearchCarByNameDAL(string Name)
        {

            try
            {
                Car objCar = objCars.Find(c => c.ManufacturerName == Name);
                return objCar;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public Car SearchCarByModelDAL(string model)
        {
            
            try
            {
                Car objCar = objCars.Find(c => c.Model == model);
                return objCar;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public List<Car> GetListDAL()
        {
            try
            {
                //List<Car> objcars = objCars.FindAll(c => c == objCar);
                return objCars;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
    }
}
