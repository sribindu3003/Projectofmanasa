﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS_Exceptions
{
    public class CIMSException : ApplicationException
    {
        public CIMSException():base() { }
        public CIMSException(string message) : base(message) { }
        public CIMSException(string message,Exception innerException) : base(message,innerException) { }
    }
}
